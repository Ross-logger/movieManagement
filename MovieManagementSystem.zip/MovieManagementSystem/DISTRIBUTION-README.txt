Movie Management System - Distribution Package
==============================================

This package contains:

1. JAR FILE:
   - movie-management-system-1.0-SNAPSHOT.jar
   - Executable JAR with Main class configured
   - Run with: java -jar movie-management-system-1.0-SNAPSHOT.jar

2. SOURCE CODE:
   - src/ - All source files
   - data/ - Data files (PredefinedAdmins, PredefinedMoviesList)

3. TEST CODE:
   - test/ - All test files (312 test methods)

4. CONFIGURATION:
   - pom.xml - Maven configuration

5. DOCUMENTATION:
   - README.md - Project documentation
   - coverage-report/ - Test coverage report (HTML)

6. SCRIPTS:
   - run-system.sh - Run the application
   - run-tests.sh - Run tests
   - compile.sh - Compile the project

QUICK START:
============

To run the application:
  java -jar movie-management-system-1.0-SNAPSHOT.jar

To build from source:
  mvn clean package

To run tests:
  mvn test

To view coverage report:
  Open coverage-report/jacoco/index.html in a web browser

REQUIREMENTS:
=============
- Java 18 or higher
- Maven (for building from source)
